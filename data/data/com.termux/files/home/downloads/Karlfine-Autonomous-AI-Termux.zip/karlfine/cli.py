
import sys
from rich.console import Console
from prompt_toolkit import prompt
from .ai import ask
from .modules.scraper import scrape
from .agents.auto_agent import run_agent

console = Console()

def main():
    console.print("[bold cyan]Karlfine Autonomous AI[/bold cyan]")
    console.print("Commands: chat | scrape <url> | agent <taskfile> | exit\n")

    if len(sys.argv) > 1:
        cmd = sys.argv[1]

        if cmd == "scrape" and len(sys.argv) > 2:
            scrape(sys.argv[2])
            return

        if cmd == "agent" and len(sys.argv) > 2:
            run_agent(sys.argv[2])
            return

    while True:
        user = prompt("You > ")

        if user.lower() in ["exit","quit"]:
            break

        response = ask(user)
        console.print(f"[green]Karlfine >[/green] {response}")
