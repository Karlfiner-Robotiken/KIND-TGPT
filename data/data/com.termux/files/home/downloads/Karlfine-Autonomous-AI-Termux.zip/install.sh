
#!/data/data/com.termux/files/usr/bin/bash

echo "Installing Karlfine Autonomous AI..."

pkg update -y
pkg upgrade -y
pkg install python git curl -y

pip install --upgrade pip
pip install openai rich prompt_toolkit requests beautifulsoup4 python-telegram-bot schedule

chmod +x scripts/karlfine
cp scripts/karlfine $PREFIX/bin/

echo ""
echo "Karlfine Autonomous AI installed."
echo "Run with: karlfine"
