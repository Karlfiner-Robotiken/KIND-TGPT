#!/data/data/com.termux/files/usr/bin/bash
set -e

BASE="$HOME/nodular"
BIN="$PREFIX/bin"

echo "Installing NODULAR..."

pkg update -y -q
pkg install -y python python-pip git -q

pip install --upgrade pip -q
pip install textual rich click pyyaml requests numpy nltk -q || true

python - <<EOF
import nltk
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
except:
    pass
EOF

mkdir -p "$BASE"
cp -r nodular/* "$BASE/"
chmod +x "$BASE/nodular.py"

cat > "$BIN/nodular" << 'EOF2'
#!/data/data/com.termux/files/usr/bin/bash
cd ~/nodular
python nodular.py
EOF2

chmod +x "$BIN/nodular"

echo "Installation complete. Run: nodular"
