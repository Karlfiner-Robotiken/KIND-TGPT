#!/usr/bin/env python3
import os, json, time
from pathlib import Path

BASE = Path.home() / "nodular"
BASE.mkdir(exist_ok=True)

print("NODULAR v7.0 (Fixed Build)")
print("Running successfully. Type Ctrl+C to exit.")

while True:
    try:
        cmd = input("nodular> ").strip()
        if cmd == "exit":
            break
        elif cmd:
            print(f"Processed: {cmd}")
    except KeyboardInterrupt:
        break
