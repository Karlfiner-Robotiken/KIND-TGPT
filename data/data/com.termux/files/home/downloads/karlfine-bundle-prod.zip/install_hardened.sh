#!/data/data/com.termux/files/usr/bin/bash
unzip -o karlfine-bundle-prod.zip
cd karlfine-ai
python main.py
