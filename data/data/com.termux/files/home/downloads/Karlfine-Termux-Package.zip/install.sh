
#!/data/data/com.termux/files/usr/bin/bash

echo "Installing Karlfine AI..."

pkg update -y
pkg upgrade -y
pkg install python git -y

pip install --upgrade pip
pip install openai rich prompt_toolkit

chmod +x scripts/karlfine
cp scripts/karlfine $PREFIX/bin/

echo ""
echo "Karlfine installed successfully"
echo "Run with: karlfine"
