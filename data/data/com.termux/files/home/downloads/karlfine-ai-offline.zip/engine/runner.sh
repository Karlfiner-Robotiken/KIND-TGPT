#!/data/data/com.termux/files/usr/bin/bash

MODEL="$HOME/karlfine-ai/models/model.bin"
LLAMA="$HOME/llama.cpp/main"

if [ ! -f "$MODEL" ]; then
    echo "❌ No model found. Download one first."
    exit 1
fi

echo "🤖 Karlfine:"
$LLAMA -m $MODEL -p "$1"
