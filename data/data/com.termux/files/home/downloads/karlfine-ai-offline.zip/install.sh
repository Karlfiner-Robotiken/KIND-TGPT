#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 Installing Karlfine AI (Offline Mode)..."

pkg update -y && pkg upgrade -y
pkg install -y git wget clang make cmake

# Install llama.cpp
cd $HOME
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make

# Create directories
mkdir -p $HOME/karlfine-ai/{models,logs}

# Move files
cp -r * $HOME/karlfine-ai/ 2>/dev/null

chmod +x $HOME/karlfine-ai/karlfine
chmod +x $HOME/karlfine-ai/engine/runner.sh

ln -sf $HOME/karlfine-ai/karlfine $PREFIX/bin/karlfine

echo "⬇️ Download a model (example tiny model)"
echo "wget -O $HOME/karlfine-ai/models/model.bin https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-GGUF/resolve/main/tinyllama-1.1b-chat.Q2_K.gguf"

echo "✅ Done! Run: karlfine"
