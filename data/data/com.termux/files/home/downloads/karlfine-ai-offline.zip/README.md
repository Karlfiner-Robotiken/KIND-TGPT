# Karlfine AI (Offline)

## Install
unzip karlfine-ai.zip
cd karlfine-ai
chmod +x install.sh
./install.sh

## Download Model
wget -O $HOME/karlfine-ai/models/model.bin https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-GGUF/resolve/main/tinyllama-1.1b-chat.Q2_K.gguf

## Run
karlfine
