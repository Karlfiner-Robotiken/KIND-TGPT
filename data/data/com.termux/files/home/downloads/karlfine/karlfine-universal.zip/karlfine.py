import os
import requests

class Karlfine:
    def __init__(self):
        self.mode = self.detect_mode()

    def detect_mode(self):
        if self.internet():
            return "cloud"
        elif os.path.exists(os.path.expanduser("~/karlfine/models/tiny.gguf")):
            return "local"
        return "safe"

    def internet(self):
        try:
            requests.get("https://api.openai.com", timeout=2)
            return True
        except:
            return False

    def local(self, prompt):
        return os.popen(f"~/karlfine/llama.cpp/main -m ~/karlfine/models/tiny.gguf -p '{prompt}' -n 150").read()

    def cloud(self, prompt):
        return "[Cloud Mode Active] " + prompt

    def safe(self, prompt):
        return "[Safe Mode] " + prompt

    def think(self, prompt):
        try:
            if self.mode == "cloud":
                return self.cloud(prompt)
            elif self.mode == "local":
                return self.local(prompt)
            return self.safe(prompt)
        except:
            return self.safe(prompt)

if __name__ == "__main__":
    ai = Karlfine()
    print("KARLFINE STABLE AI READY")
    while True:
        q = input("You: ")
        if q == "exit":
            break
        print("Karlfine:", ai.think(q))
