from flask import Flask, request
from karlfine import Karlfine

app = Flask(__name__)
ai = Karlfine()

@app.route("/chat", methods=["POST"])
def chat():
    prompt = request.json["prompt"]
    return {"response": ai.think(prompt)}

app.run(host="0.0.0.0", port=5000)
