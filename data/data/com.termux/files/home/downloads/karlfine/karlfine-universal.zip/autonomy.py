import time
from karlfine import Karlfine

ai = Karlfine()

while True:
    print("Auto:", ai.think("Suggest a useful action"))
    time.sleep(10)
