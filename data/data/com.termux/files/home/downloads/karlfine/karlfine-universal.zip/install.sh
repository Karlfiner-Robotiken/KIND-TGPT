#!/data/data/com.termux/files/usr/bin/bash
echo "[Karlfine] Installing Universal AI..."
pkg update -y && pkg upgrade -y
pkg install -y git python clang cmake make wget
mkdir -p ~/karlfine
cd ~/karlfine
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp && make -j$(nproc)
mkdir -p ~/karlfine/models
cd ~/karlfine/models
wget -q https://huggingface.co/TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF/resolve/main/tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf -O tiny.gguf
echo "[✔] Core installed"
