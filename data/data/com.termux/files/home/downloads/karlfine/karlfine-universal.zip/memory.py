memory = []

def save(x):
    memory.append(x)

def load():
    return memory[-5:]
