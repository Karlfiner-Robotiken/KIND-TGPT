# KARLFINE AI

## Install
chmod +x install.sh
./install.sh

## Run
bash run.sh

## API
python api.py

## Autonomous
python autonomy.py
