#!/data/data/com.termux/files/usr/bin/bash
python ~/karlfine/karlfine.py
