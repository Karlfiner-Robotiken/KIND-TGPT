#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 Running KIND AI v3..."
python -m kind.cli --a 10 50 90 --b 90 50 10
