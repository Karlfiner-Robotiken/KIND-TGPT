#!/data/data/com.termux/files/usr/bin/bash
echo "⚙️ Installing KIND AI v3..."

pkg update -y && pkg upgrade -y
pkg install python git -y

pip install --upgrade pip
pip install numpy flask rich

chmod +x run.sh

echo "✅ KIND AI v3 Installed!"
echo "Run: ./run.sh"
