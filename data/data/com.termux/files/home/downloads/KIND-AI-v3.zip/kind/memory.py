
import json, os

MEMORY_FILE = "memory/history.json"

def save(entry):
    os.makedirs("memory", exist_ok=True)
    try:
        data = load()
    except:
        data = []
    data.append(entry)
    with open(MEMORY_FILE, "w") as f:
        json.dump(data, f, indent=2)

def load():
    with open(MEMORY_FILE) as f:
        return json.load(f)
