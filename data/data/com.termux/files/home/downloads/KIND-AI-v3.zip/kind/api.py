
from flask import Flask, request, jsonify
from kind.engine import KIND_Engine

app = Flask(__name__)
engine = KIND_Engine()

@app.route("/solve", methods=["POST"])
def solve():
    data = request.json
    return jsonify(engine.solve(data["a"], data["b"]))

@app.route("/history", methods=["GET"])
def history():
    import json
    try:
        with open("memory/history.json") as f:
            return jsonify(json.load(f))
    except:
        return jsonify([])

app.run(host="0.0.0.0", port=5000)
