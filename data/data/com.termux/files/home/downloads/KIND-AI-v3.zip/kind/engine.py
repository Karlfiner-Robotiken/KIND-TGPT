
import numpy as np
from kind.memory import save

class KIND_Engine:
    def __init__(self):
        self.name = "KIND AI v3 (Adaptive)"

    def solve(self, a, b):
        a = np.array(a, dtype=float)
        b = np.array(b, dtype=float)

        n = min(len(a), len(b))
        a, b = a[:n], b[:n]

        eq = (a + b) / 2
        confidence = float(1 / (1 + np.linalg.norm(a - b)))

        result = {
            "engine": self.name,
            "equilibrium": eq.tolist(),
            "confidence": confidence
        }

        save(result)
        return result
