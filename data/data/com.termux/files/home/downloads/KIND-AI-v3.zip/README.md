# KIND AI v3

Adaptive AI with memory.

## Install
chmod +x install.sh
./install.sh

## Run
./run.sh

## API
python kind/api.py

Endpoints:
POST /solve
GET /history
