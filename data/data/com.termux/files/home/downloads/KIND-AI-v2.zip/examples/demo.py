from kind.engine import KIND_Engine
print(KIND_Engine().solve([1,2,3],[3,2,1]))
