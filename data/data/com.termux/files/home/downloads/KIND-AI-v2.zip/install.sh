#!/data/data/com.termux/files/usr/bin/bash
echo "⚙️ Installing KIND AI v2..."

pkg update -y && pkg upgrade -y
pkg install python git -y

pip install --upgrade pip
pip install numpy flask rich

chmod +x run.sh

echo "✅ KIND AI v2 Installed!"
echo "Run CLI: ./run.sh"
echo "Run API: python kind/api.py"
