
# KIND AI v2

## Features
- Equilibrium AI Engine
- CLI + API
- Confidence scoring
- Colored terminal output

## Install
chmod +x install.sh
./install.sh

## CLI
python -m kind.cli --a 1 2 3 --b 3 2 1

## API
python kind/api.py
