#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 Running KIND AI v2..."
python -m kind.cli --a 5 15 25 --b 25 15 5
