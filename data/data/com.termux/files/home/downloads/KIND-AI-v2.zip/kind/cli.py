
from kind.engine import KIND_Engine
from rich import print
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--a", nargs="+", type=float, required=True)
    parser.add_argument("--b", nargs="+", type=float, required=True)
    args = parser.parse_args()

    engine = KIND_Engine()
    res = engine.solve(args.a, args.b)

    print("[bold cyan]KIND AI RESULT[/bold cyan]")
    print(res)

if __name__ == "__main__":
    main()
