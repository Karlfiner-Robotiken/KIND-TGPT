#!/data/data/com.termux/files/usr/bin/bash

echo "[Karlfine Offline] Installing..."

mkdir -p ~/karlfine

cp -r ./llama.cpp ~/karlfine/
cp -r ./models ~/karlfine/
cp -r ./core ~/karlfine/

cat > $PREFIX/bin/karlfine << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
python ~/karlfine/core/karlfine.py
EOF

chmod +x $PREFIX/bin/karlfine

echo "[✔] Installed offline successfully"
echo "Run: karlfine"
