#!/data/data/com.termux/files/usr/bin/bash
echo "⚙️ Installing KIND AI Engine..."

pkg update -y && pkg upgrade -y
pkg install python git -y

pip install --upgrade pip
pip install numpy flask

chmod +x run.sh

echo "✅ KIND AI Installed Successfully!"
echo "Run: ./run.sh"
echo "API: python kind/api.py"
