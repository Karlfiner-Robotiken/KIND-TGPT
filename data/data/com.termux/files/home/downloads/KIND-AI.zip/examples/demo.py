from kind.engine import KIND_Engine

engine = KIND_Engine()
print(engine.solve([10,20,30],[30,20,10]))
