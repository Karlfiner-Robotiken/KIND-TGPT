#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 Starting KIND AI..."
python -m kind.cli --a 10 20 30 --b 30 20 10
