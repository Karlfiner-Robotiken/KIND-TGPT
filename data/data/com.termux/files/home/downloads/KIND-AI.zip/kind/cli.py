import argparse
from kind.engine import KIND_Engine

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--a", nargs="+", type=float, required=True)
    parser.add_argument("--b", nargs="+", type=float, required=True)

    args = parser.parse_args()

    engine = KIND_Engine()
    result = engine.solve(args.a, args.b)

    print(result)

if __name__ == "__main__":
    main()
