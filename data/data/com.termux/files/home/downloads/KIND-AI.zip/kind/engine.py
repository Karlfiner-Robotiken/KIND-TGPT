import numpy as np

class KIND_Engine:
    def __init__(self):
        self.name = "KIND AI"

    def solve(self, force_a, force_b):
        a = np.array(force_a, dtype=float)
        b = np.array(force_b, dtype=float)

        min_len = min(len(a), len(b))
        a = a[:min_len]
        b = b[:min_len]

        equilibrium = (a + b) / 2

        return {
            "engine": self.name,
            "equilibrium": equilibrium.tolist()
        }
