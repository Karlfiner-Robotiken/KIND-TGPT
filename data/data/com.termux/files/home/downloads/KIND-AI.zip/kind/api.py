from flask import Flask, request, jsonify
from kind.engine import KIND_Engine

app = Flask(__name__)
engine = KIND_Engine()

@app.route("/solve", methods=["POST"])
def solve():
    data = request.json
    result = engine.solve(data["a"], data["b"])
    return jsonify(result)

app.run(host="0.0.0.0", port=5000)
