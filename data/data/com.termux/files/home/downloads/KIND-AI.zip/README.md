# KIND AI

KIND AI is a quantum-inspired problem-solving engine.

## Install
chmod +x install.sh
./install.sh

## Run CLI
python -m kind.cli --a 1 2 3 --b 3 2 1

## Run API
python kind/api.py
