
import sys
from rich.console import Console
from prompt_toolkit import prompt
from .ai import ask_ai
from .modules.scraper import scrape
from .modules.auto import run_auto

console = Console()

def main():
    console.print("[bold cyan]Karlfine AI OS[/bold cyan]")
    console.print("Commands: chat | scrape <url> | auto <taskfile> | exit\n")

    if len(sys.argv) > 1:
        cmd = sys.argv[1]

        if cmd == "scrape" and len(sys.argv) > 2:
            url = sys.argv[2]
            scrape(url)
            return

        if cmd == "auto" and len(sys.argv) > 2:
            run_auto(sys.argv[2])
            return

    while True:
        user = prompt("You > ")

        if user.lower() in ["exit","quit"]:
            break

        response = ask_ai(user)
        console.print(f"[green]Karlfine >[/green] {response}")
