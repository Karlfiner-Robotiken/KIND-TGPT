
#!/data/data/com.termux/files/usr/bin/bash

echo "Installing Karlfine AI OS..."

pkg update -y
pkg upgrade -y

pkg install python git curl -y

pip install --upgrade pip
pip install openai rich prompt_toolkit requests beautifulsoup4 python-telegram-bot

chmod +x scripts/karlfine
cp scripts/karlfine $PREFIX/bin/

echo ""
echo "Karlfine AI OS installed."
echo "Run with: karlfine"
