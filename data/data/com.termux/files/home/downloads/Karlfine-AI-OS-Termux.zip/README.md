
# Karlfine AI OS (Termux)

Karlfine AI OS is an autonomous AI terminal environment designed for Termux.

## Install

unzip package
cd Karlfine_AI_OS
bash install.sh

## Run

export OPENAI_API_KEY=your_key

karlfine

## Commands

karlfine scrape https://example.com
karlfine auto task.txt

## Features

AI chat
Web scraping
Autonomous tasks
Plugin system
Telegram integration ready
